^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot4_gz_gui_plugins
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.2 (2024-10-29)
------------------

2.0.1 (2024-09-25)
------------------
* Generalize gz vendor use and modernize CMake (`#82 <https://github.com/turtlebot/turtlebot4_simulator/issues/82>`_)
* Contributors: Jose Luis Rivero

2.0.0 (2024-09-03)
------------------
* Ignition/ign rename to gz
* Update launch files to remove deprecations
* Update dependencies for Gazebo Harmonic
* Enable OSRF testing packages for Github CI
* Initial Jazzy implementation (`#80 <https://github.com/turtlebot/turtlebot4_simulator/issues/80>`_)
* Linting & formatting fixes
* Contributors: Chris Iverach-Brereton

1.0.2 (2024-04-15)
------------------

1.0.1 (2023-11-08)
------------------

1.0.0 (2023-05-16)
------------------
* Updated GUI to have namespace input
* Contributors: Hilary Luo, Roni Kreinin, roni-kreinin

0.1.1 (2022-05-09)
------------------

0.1.0 (2022-05-04)
------------------
* First Galactic release
* Contributors: Roni Kreinin
